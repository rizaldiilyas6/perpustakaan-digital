// Ambil elemen-elemen yang diperlukan dari halaman HTML
const searchInput = document.querySelector('#search input[type="text"]');
const searchButton = document.querySelector('#search button');
const genreSections = document.querySelectorAll('#genres .genre');
const newsArticles = document.querySelectorAll('#news .article');

// Fungsi pencarian buku
function searchBooks() {
  const searchTerm = searchInput.value.toLowerCase();
  if (searchTerm.trim() !== '') {
    // Simulasi pencarian (contoh)
    alert(`Mencari buku dengan kata kunci: ${searchTerm}`);
    // Reset input setelah pencarian
    searchInput.value = '';
  } else {
    alert('Masukkan kata kunci pencarian!');
  }
}

// Tambahkan event listener untuk tombol pencarian
searchButton.addEventListener('click', searchBooks);

// Fungsi untuk menampilkan detail genre ketika diklik
function showGenreDetail(event) {
  const genreDetail = event.currentTarget.querySelector('p');
  genreDetail.classList.toggle('show');
}

// Tambahkan event listener untuk setiap section genre
genreSections.forEach(section => {
  section.addEventListener('click', showGenreDetail);
});

// Fungsi untuk menampilkan detail berita ketika diklik
function showArticleDetail(event) {
  const articleDetail = event.currentTarget.querySelector('p');
  articleDetail.classList.toggle('show');
}

// Tambahkan event listener untuk setiap section berita
newsArticles.forEach(section => {
  section.addEventListener('click', showArticleDetail);
});
